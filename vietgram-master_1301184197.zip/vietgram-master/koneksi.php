<?php

$conn = mysqli_connect("localhost","root","","tugas_instagram") or die ("Koneksi gagal!");

?>